import React, { useState } from 'react';


export default function BulkUpload({ testId, onUploaded }) {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('');

  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return setStatus('Please choose a CSV file');
    setStatus('Uploading...');
    try {
      const res = await uploadCSV(testId, file);
      setStatus(`Inserted ${res.insertedCount}. Errors: ${res.errors?.length || 0}`);
      if (onUploaded) onUploaded();
    } catch (err) {
      setStatus(err.response?.data?.error || err.message);
    }
  }

  return (
    <div style={{marginTop:12, borderTop:'1px dashed #ddd', paddingTop:12}}>
      <h5>Bulk Upload (CSV)</h5>
      <form onSubmit={handleUpload}>
        <input accept=".csv,text/csv" type="file" onChange={e=>setFile(e.target.files[0])} />
        <div style={{marginTop:8}}>
          <button type="submit">Upload CSV</button>
        </div>
      </form>
      {status && <div style={{marginTop:8}}>{status}</div>}
      <div style={{marginTop:8, fontSize:13, color:'#333'}}>
        CSV columns (order): questionText,option1,option2,option3,option4,correctAnswer<br/>
        Example: <code>What is 2+2?,1,2,3,4,4</code>
      </div>
    </div>
  );
}
