import React from 'react'

export default function Navbar({ onLogout }){
  return (
    <nav className="nav">
      <div className="nav-left">Test Management</div>
      <div>
        <button className="btn" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  )
}
