import React, { useEffect, useState } from 'react';
import { LogOut, Plus, RefreshCw, Users, FileText, BarChart3 } from 'lucide-react';

// Mock components for demo
const CreateTest = ({ onCreated }) => (
  <div style={{
    background: 'white',
    padding: '24px',
    borderRadius: '12px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    marginBottom: '24px'
  }}>
    <h3 style={{ margin: '0 0 16px 0', color: '#1f2937', fontSize: '18px', fontWeight: '600' }}>
      Create New Test
    </h3>
    <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
      <input 
        placeholder="Test name" 
        style={{
          padding: '10px 14px',
          border: '2px solid #e5e7eb',
          borderRadius: '8px',
          fontSize: '14px',
          flex: 1
        }}
      />
      <button
        onClick={() => onCreated()}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '10px 20px',
          background: '#10b981',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          fontSize: '14px',
          fontWeight: '500',
          cursor: 'pointer'
        }}
      >
        <Plus size={16} />
        Create Test
      </button>
    </div>
  </div>
);

const TestList = ({ tests, refreshTests }) => (
  <div style={{
    background: 'white',
    borderRadius: '12px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden'
  }}>
    <div style={{
      padding: '20px 24px',
      borderBottom: '1px solid #e5e7eb',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }}>
      <h3 style={{ margin: 0, color: '#1f2937', fontSize: '18px', fontWeight: '600' }}>
        Tests ({tests.length})
      </h3>
      <button
        onClick={refreshTests}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          padding: '8px 12px',
          background: '#f3f4f6',
          color: '#6b7280',
          border: 'none',
          borderRadius: '6px',
          fontSize: '14px',
          cursor: 'pointer'
        }}
      >
        <RefreshCw size={14} />
        Refresh
      </button>
    </div>
    
    {tests.length === 0 ? (
      <div style={{
        padding: '48px 24px',
        textAlign: 'center',
        color: '#6b7280'
      }}>
        <FileText size={48} style={{ margin: '0 auto 16px', opacity: 0.3 }} />
        <p style={{ margin: 0, fontSize: '16px' }}>No tests created yet</p>
        <p style={{ margin: '4px 0 0', fontSize: '14px', opacity: 0.8 }}>
          Create your first test to get started
        </p>
      </div>
    ) : (
      <div>
        {tests.map((test, index) => (
          <div
            key={index}
            style={{
              padding: '16px 24px',
              borderBottom: index < tests.length - 1 ? '1px solid #f3f4f6' : 'none',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <div>
              <h4 style={{ margin: '0 0 4px 0', color: '#1f2937', fontSize: '16px' }}>
                Test {index + 1}
              </h4>
              <p style={{ margin: 0, color: '#6b7280', fontSize: '14px' }}>
                Created recently
              </p>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button style={{
                padding: '6px 12px',
                background: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '12px',
                cursor: 'pointer'
              }}>
                Edit
              </button>
              <button style={{
                padding: '6px 12px',
                background: '#ef4444',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '12px',
                cursor: 'pointer'
              }}>
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    )}
  </div>
);

export default function Dashboard() {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user] = useState({ name: 'Admin User', email: 'admin@example.com' });

  async function loadTests() {
    setLoading(true);
    try {
      // Simulate API call
      setTimeout(() => {
        setTests([
          { id: 1, name: 'Math Quiz', questions: 10 },
          { id: 2, name: 'Science Test', questions: 15 },
          { id: 3, name: 'History Exam', questions: 20 }
        ]);
        setLoading(false);
      }, 1000);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  }

  function handleLogout() {
    if (window.confirm('Are you sure you want to logout?')) {
      alert('Logged out successfully!');
    }
  }

  useEffect(() => { loadTests(); }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f0f9ff 0%, #e0e7ff 100%)',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      {/* Header */}
      <div style={{
        background: 'white',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
        borderBottom: '1px solid #e5e7eb'
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '16px 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <BarChart3 size={20} color="white" />
            </div>
            <div>
              <h1 style={{
                margin: 0,
                fontSize: '24px',
                fontWeight: '700',
                color: '#1f2937'
              }}>
                Admin Dashboard
              </h1>
              <p style={{
                margin: 0,
                fontSize: '14px',
                color: '#6b7280'
              }}>
                Manage your tests and content
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ textAlign: 'right' }}>
              <p style={{
                margin: 0,
                fontSize: '14px',
                fontWeight: '500',
                color: '#1f2937'
              }}>
                {user.name}
              </p>
              <p style={{
                margin: 0,
                fontSize: '12px',
                color: '#6b7280'
              }}>
                {user.email}
              </p>
            </div>
            <button
              onClick={handleLogout}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 16px',
                background: '#f3f4f6',
                color: '#374151',
                border: 'none',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.target.style.background = '#e5e7eb';
              }}
              onMouseLeave={(e) => {
                e.target.style.background = '#f3f4f6';
              }}
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '24px',
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '20px',
          marginBottom: '32px'
        }}>
          {[
            { title: 'Total Tests', value: tests.length, color: '#3b82f6', icon: FileText },
            { title: 'Active Users', value: '1,234', color: '#10b981', icon: Users },
            { title: 'Completion Rate', value: '87%', color: '#f59e0b', icon: BarChart3 }
          ].map((stat, index) => (
            <div
              key={index}
              style={{
                background: 'white',
                padding: '24px',
                borderRadius: '12px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                display: 'flex',
                alignItems: 'center',
                gap: '16px'
              }}
            >
              <div style={{
                width: '48px',
                height: '48px',
                background: `${stat.color}15`,
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <stat.icon size={24} color={stat.color} />
              </div>
              <div>
                <p style={{
                  margin: '0 0 4px 0',
                  fontSize: '14px',
                  color: '#6b7280'
                }}>
                  {stat.title}
                </p>
                <p style={{
                  margin: 0,
                  fontSize: '24px',
                  fontWeight: '700',
                  color: '#1f2937'
                }}>
                  {stat.value}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Main Content */}
        <CreateTest onCreated={() => loadTests()} />
        
        {loading ? (
          <div style={{
            background: 'white',
            padding: '48px',
            borderRadius: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
            textAlign: 'center'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              border: '4px solid #e5e7eb',
              borderTop: '4px solid #3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }} />
            <p style={{ margin: 0, color: '#6b7280', fontSize: '16px' }}>
              Loading tests...
            </p>
          </div>
        ) : (
          <TestList tests={tests} refreshTests={loadTests} />
        )}
      </div>

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}