import React from 'react'
import TestCard from '../Components/TestCard'

export default function ViewTests({ tests }){
  return (
    <div>
      <h3>Tests</h3>
      {tests.length === 0 && <p>No tests yet</p>}
      {tests.map(t => <TestCard key={t._id} test={t} />)}
    </div>
  )
}